import type { ButtonHTMLAttributes, HTMLAttributes } from "react";
import { cx } from "./wikiUtils";

export interface NavigateItemProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  state?: "default" | "hover" | "active";
}

export function NavigateItem({ state = "default", className = "", children, ...props }: NavigateItemProps) {
  return (
    <button type="button" className={cx("gt-wiki-navigate-item", `gt-wiki-navigate-item--${state}`, className)} {...props}>
      {children}
    </button>
  );
}

export interface NavigateProps extends HTMLAttributes<HTMLElement> {
  items?: Array<{ id: string; label: string; state?: "default" | "hover" | "active" }>;
}

export function Navigate({ items, className = "", children, ...props }: NavigateProps) {
  const resolvedItems =
    items ?? [
      { id: "intro", label: "概览", state: "active" as const },
      { id: "data", label: "资料" },
      { id: "tips", label: "技巧" },
    ];

  return (
    <nav className={cx("gt-wiki-navigate", className)} aria-label="页内导航" {...props}>
      {children ??
        resolvedItems.map((item) => (
          <NavigateItem key={item.id} state={item.state}>
            {item.label}
          </NavigateItem>
        ))}
    </nav>
  );
}
