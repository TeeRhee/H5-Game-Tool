import type { HTMLAttributes } from "react";
import { Badge } from "./Badge";
import { ImageFrame } from "./ImageFrame";
import { cx } from "./wikiUtils";

export interface WikiDescribeCardProps extends HTMLAttributes<HTMLElement> {
  title: string;
  description?: string;
  imageSrc?: string;
  size?: "sm" | "lg";
  state?: "default" | "hover";
  badges?: string[];
  attributes?: Array<{ label: string; value: string }>;
}

export function WikiDescribeCard({
  title,
  description,
  imageSrc,
  size = "sm",
  state = "default",
  badges = [],
  attributes = [],
  className = "",
  ...props
}: WikiDescribeCardProps) {
  return (
    <article className={cx("gt-wiki-describe-card", `gt-wiki-describe-card--${size}`, `gt-wiki-describe-card--${state}`, className)} {...props}>
      {imageSrc ? <ImageFrame ratio={size === "lg" ? "16:9" : "1:1"} src={imageSrc} alt="" /> : null}
      <div className="gt-wiki-describe-card__body">
        <div className="gt-wiki-describe-card__title-row">
          <h3>{title}</h3>
          {badges.map((badge) => (
            <Badge key={badge}>{badge}</Badge>
          ))}
        </div>
        {description ? <p>{description}</p> : null}
        {attributes.length > 0 ? (
          <dl className="gt-wiki-describe-card__attributes">
            {attributes.map((item) => (
              <div key={item.label}>
                <dt>{item.label}</dt>
                <dd>{item.value}</dd>
              </div>
            ))}
          </dl>
        ) : null}
      </div>
    </article>
  );
}
