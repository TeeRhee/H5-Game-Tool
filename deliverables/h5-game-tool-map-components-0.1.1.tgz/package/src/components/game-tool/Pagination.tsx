import type { ButtonHTMLAttributes, HTMLAttributes } from "react";
import { RemixIcon } from "./RemixIcon";
import { cx } from "./wikiUtils";

export interface PaginationCellProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  state?: "default" | "hover" | "selected";
}

export function PaginationCell({ state = "default", className = "", children, ...props }: PaginationCellProps) {
  return (
    <button type="button" className={cx("gt-wiki-pagination-cell", `gt-wiki-pagination-cell--${state}`, className)} {...props}>
      {children}
    </button>
  );
}

export interface PaginationProps extends HTMLAttributes<HTMLElement> {
  page?: number;
  totalPages?: number;
}

export function Pagination({ page = 2, totalPages = 5, className = "", ...props }: PaginationProps) {
  const pages = Array.from({ length: totalPages }, (_item, index) => index + 1);
  return (
    <nav className={cx("gt-wiki-pagination", className)} aria-label="分页" {...props}>
      <button type="button" className="gt-wiki-pagination__arrow" aria-label="上一页">
        <RemixIcon name="arrow-left-s-line" size={20} />
      </button>
      <div className="gt-wiki-pagination__cells">
        {pages.map((item) => (
          <PaginationCell key={item} state={item === page ? "selected" : "default"}>
            {item}
          </PaginationCell>
        ))}
      </div>
      <button type="button" className="gt-wiki-pagination__arrow" aria-label="下一页">
        <RemixIcon name="arrow-right-s-line" size={20} />
      </button>
    </nav>
  );
}
