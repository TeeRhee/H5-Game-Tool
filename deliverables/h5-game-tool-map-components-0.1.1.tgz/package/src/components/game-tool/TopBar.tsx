import type { ButtonHTMLAttributes, HTMLAttributes } from "react";
import { cx, type WikiVisualState } from "./wikiUtils";

export interface TopBarItemProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  state?: WikiVisualState;
}

export function TopBarItem({ state = "default", className = "", children, ...props }: TopBarItemProps) {
  return (
    <button type="button" className={cx("gt-wiki-topbar-item", `gt-wiki-topbar-item--${state}`, className)} {...props}>
      {children}
    </button>
  );
}

export interface TopBarProps extends HTMLAttributes<HTMLElement> {
  items?: Array<{ id: string; label: string; state?: WikiVisualState }>;
}

export function TopBar({ items, className = "", children, ...props }: TopBarProps) {
  const resolvedItems =
    items ?? [
      { id: "home", label: "首页", state: "active" as const },
      { id: "guide", label: "攻略" },
      { id: "item", label: "资料" },
      { id: "event", label: "活动" },
    ];

  return (
    <nav className={cx("gt-wiki-topbar", className)} aria-label="Wiki 主导航" {...props}>
      {children ??
        resolvedItems.map((item) => (
          <TopBarItem key={item.id} state={item.state}>
            {item.label}
          </TopBarItem>
        ))}
    </nav>
  );
}
