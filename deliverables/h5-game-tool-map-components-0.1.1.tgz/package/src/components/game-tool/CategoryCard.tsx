import type { ButtonHTMLAttributes } from "react";
import { RemixIcon } from "./RemixIcon";
import { cx } from "./wikiUtils";

export interface CategoryCardProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  title: string;
  description?: string;
  imageSrc?: string;
  state?: "default" | "hover";
  meta?: string;
}

export function CategoryCard({ title, description, imageSrc, state = "default", meta, className = "", ...props }: CategoryCardProps) {
  return (
    <button type="button" className={cx("gt-wiki-category-card", `gt-wiki-category-card--${state}`, className)} {...props}>
      <span className="gt-wiki-category-card__media">
        {imageSrc ? <img src={imageSrc} alt="" /> : <RemixIcon name="image-line" size={24} />}
      </span>
      <span className="gt-wiki-category-card__content">
        <span className="gt-wiki-category-card__title">{title}</span>
        {description ? <span className="gt-wiki-category-card__description">{description}</span> : null}
        {meta ? <span className="gt-wiki-category-card__meta">{meta}</span> : null}
      </span>
      <RemixIcon name="arrow-right-s-line" size={20} className="gt-wiki-category-card__arrow" />
    </button>
  );
}
