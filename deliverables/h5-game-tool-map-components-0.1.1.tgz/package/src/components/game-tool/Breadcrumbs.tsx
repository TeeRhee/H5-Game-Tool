import type { ButtonHTMLAttributes, HTMLAttributes } from "react";
import { RemixIcon } from "./RemixIcon";
import { cx } from "./wikiUtils";

export interface BreadcrumbItemProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  state?: "default" | "hover" | "active";
}

export function BreadcrumbItem({ state = "default", className = "", children, ...props }: BreadcrumbItemProps) {
  return (
    <button type="button" className={cx("gt-wiki-breadcrumb-item", `gt-wiki-breadcrumb-item--${state}`, className)} {...props}>
      {children}
    </button>
  );
}

export interface BreadcrumbsProps extends HTMLAttributes<HTMLElement> {
  items?: Array<{ id: string; label: string }>;
}

export function Breadcrumbs({ items, className = "", ...props }: BreadcrumbsProps) {
  const resolvedItems =
    items ?? [
      { id: "home", label: "首页" },
      { id: "category", label: "资料库" },
      { id: "detail", label: "详情" },
    ];

  return (
    <nav className={cx("gt-wiki-breadcrumbs", className)} aria-label="面包屑" {...props}>
      {resolvedItems.map((item, index) => (
        <span key={item.id} className="gt-wiki-breadcrumbs__part">
          <BreadcrumbItem state={index === resolvedItems.length - 1 ? "active" : "default"}>{item.label}</BreadcrumbItem>
          {index < resolvedItems.length - 1 ? <RemixIcon name="arrow-right-s-line" size={16} /> : null}
        </span>
      ))}
    </nav>
  );
}
