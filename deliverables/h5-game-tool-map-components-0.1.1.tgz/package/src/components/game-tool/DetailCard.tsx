import { Fragment, type HTMLAttributes, type ReactNode } from "react";
import { Badge } from "./Badge";
import { TableHeaderCell, TableRowCell } from "./TableCell";
import { cx } from "./wikiUtils";

export interface DetailCardProps extends HTMLAttributes<HTMLElement> {
  title: string;
  description?: string;
  badges?: string[];
  table?: Array<{ label: string; value: string; icon?: ReactNode }>;
  aside?: ReactNode;
}

export function DetailCard({ title, description, badges = [], table = [], aside, className = "", children, ...props }: DetailCardProps) {
  return (
    <article className={cx("gt-wiki-detail-card", className)} {...props}>
      <header className="gt-wiki-detail-card__header">
        <div>
          <h3>{title}</h3>
          {description ? <p>{description}</p> : null}
        </div>
        <div className="gt-wiki-detail-card__badges">
          {badges.map((badge) => (
            <Badge key={badge} tone="primary">
              {badge}
            </Badge>
          ))}
        </div>
      </header>
      <div className="gt-wiki-detail-card__content">
        <div className="gt-wiki-detail-card__main">
          {children}
          {table.length > 0 ? (
            <div className="gt-wiki-table">
              <TableHeaderCell>属性</TableHeaderCell>
              <TableHeaderCell>数值</TableHeaderCell>
              {table.map((row) => (
                <Fragment key={row.label}>
                  <TableRowCell icon={row.icon}>{row.label}</TableRowCell>
                  <TableRowCell>{row.value}</TableRowCell>
                </Fragment>
              ))}
            </div>
          ) : null}
        </div>
        {aside ? <aside className="gt-wiki-detail-card__aside">{aside}</aside> : null}
      </div>
    </article>
  );
}
