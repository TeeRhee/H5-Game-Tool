import type { HTMLAttributes } from "react";
import { SearchBar } from "./SearchBar";
import { TopBar } from "./TopBar";
import { cx } from "./wikiUtils";

export interface HeaderProps extends HTMLAttributes<HTMLElement> {
  searchValue?: string;
  onSearchChange?: (value: string) => void;
  searchPlaceholder?: string;
}

export function Header({
  searchValue = "",
  onSearchChange,
  searchPlaceholder = "搜索 Wiki 内容",
  className = "",
  children,
  ...props
}: HeaderProps) {
  return (
    <header className={cx("gt-wiki-header", className)} {...props}>
      {children ?? <TopBar />}
      <div className="gt-wiki-header__search">
        <SearchBar value={searchValue} placeholder={searchPlaceholder} onChange={onSearchChange ?? (() => undefined)} />
      </div>
    </header>
  );
}
