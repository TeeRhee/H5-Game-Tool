import type { ButtonHTMLAttributes, ReactNode } from "react";
import { Badge } from "./Badge";
import { cx } from "./wikiUtils";

export interface CommandMenuItemProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  icon?: ReactNode;
  badge?: string;
  state?: "default" | "hover";
}

export function CommandMenuItem({ icon, badge, state = "default", className = "", children, ...props }: CommandMenuItemProps) {
  return (
    <button type="button" className={cx("gt-wiki-command-item", `gt-wiki-command-item--${state}`, className)} {...props}>
      {icon ? <span className="gt-wiki-command-item__icon">{icon}</span> : null}
      <span className="gt-wiki-command-item__label">{children}</span>
      {badge ? <Badge>{badge}</Badge> : null}
    </button>
  );
}
