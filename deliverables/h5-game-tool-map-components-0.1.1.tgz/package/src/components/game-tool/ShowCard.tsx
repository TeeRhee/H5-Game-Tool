import type { ButtonHTMLAttributes } from "react";
import { Badge } from "./Badge";
import { ImageFrame } from "./ImageFrame";
import { ProgressBar } from "./ProgressBar";
import { RemixIcon } from "./RemixIcon";
import { cx } from "./wikiUtils";

export interface ShowCardProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  title: string;
  description?: string;
  imageSrc?: string;
  label?: string;
  progress?: number;
  variant?: "label" | "process";
  subscribed?: boolean;
}

export function ShowCard({
  title,
  description,
  imageSrc,
  label,
  progress,
  variant = "label",
  subscribed = false,
  className = "",
  ...props
}: ShowCardProps) {
  return (
    <button type="button" className={cx("gt-wiki-show-card", `gt-wiki-show-card--${variant}`, className)} {...props}>
      {imageSrc ? <ImageFrame ratio="1:1" src={imageSrc} alt="" /> : null}
      <span className="gt-wiki-show-card__content">
        <span className="gt-wiki-show-card__title">{title}</span>
        {description ? <span className="gt-wiki-show-card__description">{description}</span> : null}
        {variant === "process" && typeof progress === "number" ? <ProgressBar value={progress} /> : null}
      </span>
      {label ? <Badge tone={subscribed ? "success" : "neutral"}>{label}</Badge> : null}
      <RemixIcon name="arrow-right-s-line" size={20} className="gt-wiki-show-card__arrow" />
    </button>
  );
}
