import type { HTMLAttributes } from "react";
import { cx } from "./wikiUtils";

export function PageShell({ className = "", children, ...props }: HTMLAttributes<HTMLDivElement>) {
  return (
    <section className={cx("gt-wiki-page-shell", className)} {...props}>
      {children}
    </section>
  );
}
